﻿namespace MvcMovie.Views.HelloWorld
{
    public class MvcMovie
    {
    }
}
